<section class="intrested-sec">
    <div class="wrapper">
        <div class="intrested-inner">
            <div class="heading">you might be <span>Interested in</span></div>
            <ul class="intrested-list">
                <li class="case-studies"><a href="case-study.php">Case Studies</a></li>
                <li class="research"><a href="research.php">Research</a></li>
                <li class="news-views"><a href="news-views.php">News & Views</a></li>
            </ul>
        </div>
    </div>
</section>