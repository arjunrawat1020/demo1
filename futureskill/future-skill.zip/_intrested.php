<section class="intrested-sec">
    <div class="wrapper">
        <div class="intrested-inner">
            <div class="heading">you might be <span>Interested in</span></div>
            <ul class="intrested-list">
                <li class="case-studies"><a href="about-futureskill.php">What is FutureSkills?</a></li>
                <li class="research"><a href="how-does-it-work.php">How Does It Work?</a></li>
                <li class="news-views"><a class="intrestedJoinForm">How Can You Join?</a></li>
            </ul>
        </div>
    </div>
</section>