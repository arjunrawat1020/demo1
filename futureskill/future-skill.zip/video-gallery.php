<?php include('head.php'); ?>
<?php include('navigation.php'); ?>
<section class="home-banner inner-banner">
	<img src="img/gallery/video-banner-bg.jpg" alt="" height="400px" width="1366px" class="inner-banner-bg">
	<div class="wrapper">
		<div class="banner-content">
			<div class="banner-heading"> <span>video </span>gallery</div>
		</div>
	</div>
</section>
<section class="breadcum">
	<div class="wrapper">
		<ul>
			<li>Home</li>
			<li class="seprator"><img src="img/bradcum-arrow.png" alt=""></li>
			<li>take a look</li>
			<li class="seprator"><img src="img/bradcum-arrow.png" alt=""></li>
			<li class="active">video gallery</li>
		</ul>
	</div>
</section>

<section class="news-sec photo-gallery-sec video-gallery-sec">
	<div class="wrapper">
		<ul>
			<!-- <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod." data-width="800" data-height="500">
                    <img src="img/gallery/photo1.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">FutureSkills: Portal Walk-through</div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li>
            <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod.">
                    <img src="img/gallery/photo2.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">FutureSkills: Best-in-class content </div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li>
            <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod.">
                    <img src="img/gallery/photo3.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">FutureSkills: Tech-skilling with the Experts</div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li>
            <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod.">
                    <img src="img/gallery/photo4.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">FutureSkills: An Industry-driven learning Ecosystem</div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li>
            <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod.">
                    <img src="img/gallery/photo5.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">The Skilling Imperative for SMEs</div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li>
            <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod.">
                    <img src="img/gallery/photo6.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">FutureSkills: Portal Walk-through</div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li>
            <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod.">
                    <img src="img/gallery/photo7.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">FutureSkills: Portal Walk-through</div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li>
            <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod.">
                    <img src="img/gallery/photo8.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">FutureSkills: Portal Walk-through</div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li>
            <li>
                <a href="https://www.youtube.com/embed/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery"
                    data-caption="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod.">
                    <img src="img/gallery/photo9.png" alt="">
                </a>
                <div class="context">
                    <div class="heading">FutureSkills: Portal Walk-through</div>
                    <p><strong> Published :</strong> 20th September 2018</p>
                </div>
            </li> -->

			<li>
				<a href="https://youtu.be/TWwkmg7OxzQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery" data-caption="FutureSkills: Portal Walkthrough">
					<img src="img/gallery/v-thumb1.jpg" alt="">
				</a>
				<div class="context">
					<div class="heading">FutureSkills: Portal Walkthrough</div>
					<p class="content mCustomScrollbar">Get a glimpse of the FutureSkills portal through this video. Learn how the portal uses an easy to navigate interface that enables the users to explore future technologies, upcoming jobs in those technologies and the skills required to do those jobs. Also learn the various features and tools that helps the learner navigate through the portal.</p>
					<!-- <p><strong> Published :</strong> 20th September 2018</p> -->
				</div>
				<div class="cat-label programme">Programme Video</div>
			</li>
			<li>
				<a href="https://youtu.be/9vTKHWvseAA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery" data-caption="FutureSkills: Best-in-class content">
					<img src="img/gallery/v-thumb1.jpg" alt="">
				</a>
				<div class="context">
					<div class="heading">FutureSkills: Best-in-class content</div>
					<p class="content mCustomScrollbar">Carry an entire library of knowledge no matter where you go. Learn how FutureSkills offers content in the form of SmartCards that allow learning on-the-go. Also learn about SME curated content that's relevant to the industry</p>
					<!-- <p><strong> Published :</strong> 20th September 2018</p> -->
				</div>
				<div class="cat-label programme">Programme Video</div>
			</li>
			<li>
				<a href="https://youtu.be/g6cQdoZcru0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery" data-caption="FutureSkills: Tech-skilling with the Experts">
					<img src="img/gallery/v-thumb1.jpg" alt="">
				</a>
				<div class="context">
					<div class="heading">FutureSkills: Tech-skilling with the Experts</div>
					<p class="content mCustomScrollbar">Subject Matter Experts play a crucial role in helping the workforce of tomorrow. Learn how you can contribute as an SME on the FutureSkills portal.</p>
				</div>
				<div class="cat-label programme">Programme Video</div>
			</li>
			<li>
				<a href="https://youtu.be/NW4WNkhGHbQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery" data-caption="FutureSkills: An Industry-driven learning Ecosystem">
					<img src="img/gallery/v-thumb1.jpg" alt="">
				</a>
				<div class="context">
					<div class="heading">FutureSkills: An Industry-driven learning Ecosystem</div>
					<p class="content mCustomScrollbar">NASSCOM FutureSkills is an industry driven learning eco-system to get India accelerated on the journey to building skills and becoming the global hub for talent in emerging technologies. Learn more about the initiative in this video that sets the background of the programme and gives a broad overview of NASSCOM's flagship initiative on reskilling.</p>
				</div>
				<div class="cat-label programme">Programme Video</div>
			</li>
			<li>
				<a href="https://youtu.be/0g09PrboOH0 " frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" data-fancybox="gallery" data-caption="The Skilling Imperative for SMEs">
					<img src="img/gallery/v-thumb2.jpg" alt="">
				</a>
				<div class="context">
					<div class="heading">The Skilling Imperative for SMEs</div>
					<p class="content mCustomScrollbar">Small and Medium Enterprises (SMEs) don’t have the luxury of a bench or hiring ahead of demand. Managing the world of today with the emerging needs of tomorrow is a balancing act that needs to play out in order to stay relevant in the age of Indutsry 4.0. How is this being managed by SMEs? What are some must-dos for SMEs to stay ahead of the game today and prepare for what is to come? Watch this interesting session where experts and heads of leading SMEs share their experiences and insights.</p>
				</div>
				<div class="cat-label event">Event Video</div>
			</li>
		</ul>
	</div>
</section>

<!-- Intrested Section -->
<?php include('_intrested.php'); ?>
<!-- Join Us PopUp Form -->
<section class="howCanYouJoin"><?php include('_join-form.php'); ?></section>
<!-- Footer Section -->
<?php include('footer.php'); ?>
