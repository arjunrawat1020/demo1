 <footer>
       <div class="container">
             Copyright © 2019 Ruskoo. Terms & Conditions | Disclaimer. All Rights Reserved.
       </div>
       <a href="https://bit.ly/1LHtM0P" target="_blank"></a>
 </footer>

 <div class="rotate">

 </div>