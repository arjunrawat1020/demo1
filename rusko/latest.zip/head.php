<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Rusko</title>
<link rel="stylesheet" href="css/slick-theme.css">
<link rel="stylesheet" href="css/wow.css">
<link rel="stylesheet" href="css/slick.css">
<link rel="stylesheet" href="css/main.css">
<script src="js/jquery.min.js"></script>
<script src="js/jquery.fsscroll.js"></script>
<script src="js/jquerySlim.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/wow.js"></script>
<script src="js/rusko-custom.js"></script>